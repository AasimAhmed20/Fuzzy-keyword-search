<!-- main_body  -->
<div class="main_body_wrapper">
	<div class="error">
	</div>
	
	<div class="reg_log">
			<h2>Logout Successful</h2>
	</div>
	
	<div id="admin_log">	
			<br>
			
			<?php
					$imputKey = "My text to encrypt";
					$blockSize = 256;
					$aes = new AES($imputText);
					$enc = $aes->encrypt();
					die;
			
			?>
			
			<br>
	</div>
</div>