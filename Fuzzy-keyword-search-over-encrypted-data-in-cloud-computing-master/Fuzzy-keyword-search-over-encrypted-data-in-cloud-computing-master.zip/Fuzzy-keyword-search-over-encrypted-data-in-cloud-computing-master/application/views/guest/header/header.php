<html>
	<head>
		<title>Home Page</title>
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/main.css">
		<link rel="shortcut icon" href="<?php echo base_url();?>assets/imgs/favicon.ico" type="image/ico">
	</head>
	<body>
		
		<!-- header  -->
		<div class="header_wrapper">
			<div class="heading">
				<h1>Efficient Keyword Search Over Encrypted Cloud</h1>
			</div>
		</div>