<!-- footer  -->
		<div class="footer_wrapper">
			<div id="powered_block">
			<a>Powered by CodeIgniter framework PHP.</a>
			</div>
		</div>
		
	</body>
</html>